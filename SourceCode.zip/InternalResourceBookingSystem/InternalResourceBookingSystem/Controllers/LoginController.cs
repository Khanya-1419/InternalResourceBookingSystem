﻿using Microsoft.AspNetCore.Mvc;

namespace InternalResourceBookingSystem.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string username, string password)
        {
            // Simple demo check — replace this with real authentication later
            if (username == "admin" && password == "1234")
            {
                // Redirect to homepage or resources
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }
    }
}
