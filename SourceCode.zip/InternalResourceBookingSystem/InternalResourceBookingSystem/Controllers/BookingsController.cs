﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using InternalResourceBookingSystem.Data;
using InternalResourceBookingSystem.Models;

namespace InternalResourceBookingSystem.Controllers
{
    public class BookingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Bookings
        public async Task<IActionResult> Index()
        {
            var bookings = await _context.Bookings
                .Include(b => b.Resource)
                .OrderBy(b => b.StartTime)
                .ToListAsync();

            return View(bookings);
        }

        // GET: Bookings/Create
        public IActionResult Create()
        {
            ViewBag.Resources = _context.Resources
                .Where(r => r.IsAvailable)
                .ToList();
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Booking booking)
        {
            if (booking.EndTime <= booking.StartTime)
            {
                ModelState.AddModelError("", "End time must be after start time.");
            }

            // Check for conflict
            var conflicts = _context.Bookings.Any(b =>
                b.ResourceId == booking.ResourceId &&
                b.StartTime < booking.EndTime &&
                booking.StartTime < b.EndTime
            );

            if (conflicts)
            {
                ModelState.AddModelError("", "This resource is already booked during the selected time.");
            }

            if (ModelState.IsValid)
            {
                _context.Bookings.Add(booking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Resources = _context.Resources
                .Where(r => r.IsAvailable)
                .ToList();

            return View(booking);
        }
    }
}
